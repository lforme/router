#!/bin/sh
python3 scheme-autogen.py ${AppId} ${version} ${language}
