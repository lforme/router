import json
import time 
import sys
import os
import urllib.request
import swiftAutogen

header_file_name_tpl = 'YPPRouter+{module_name}.h'

params_builder_name_tpl = 'YPP{path_id}ParamsBuilder'

header_file_content_tpl = '''//
//  YPPRouter+{module_name}.h
//  ypp-router
//
//  Created by AutoGen.
//

#import "YPPRouter.h"
#import "YPPBaseParamsBuilder.h"

NS_ASSUME_NONNULL_BEGIN

{params_definition}

{action_definition}

NS_ASSUME_NONNULL_END
'''

params_definition_tpl = '''
@interface {params_builder_name} : YPPBaseParamsBuilder

{property_definition}

@end
'''

action_definition_tpl = '''
#pragma mark - action definition
@interface YPPRouter ({module_name})

{function_definition}

@end
'''

impl_file_name_tpl = 'YPPRouter+{module_name}.m'
impl_file_content_tpl = '''//
//  YPPRouter+{module_name}.m
//  ypp-router
//
//  Created by AutoGen.
//

#import "YPPRouter+{module_name}.h"

{impl_content}

'''

impl_method_tpl = '''
@implementation {params_builder_name}
@end
'''

params_type_map = {
    'string': '@property (nonatomic, copy) NSString *',
    'int': '@property (nonatomic, assign) NSInteger ',
    'bool': '@property (nonatomic, assign) BOOL ',
    'BOOL': '@property (nonatomic, assign) BOOL ',
    'integer': '@property (nonatomic, assign) NSInteger ',
    'CGRect': '@property (nonatomic, assign) CGRect ',
    'CGPoint': '@property (nonatomic, assign) CGPoint ',
    'CGSize': '@property (nonatomic, assign) CGSize ',
    'CGFloat': '@property (nonatomic, assign) CGFloat ',
    'float': '@property (nonatomic, assign) float ',
    'double': '@property (nonatomic, assign) double ',
    'CLass': '@property (nonatomic, strong) Class ',
    'id': '@property (nonatomic, strong) id ',
    'iOS_id': '@property (nonatomic, strong) id ',
    'UIEdgeInsets': '@property (nonatomic, assign) UIEdgeInsets ',
    'NSRange': '@property (nonatomic, assign) NSRange ',
    'NSArray': '@property (nonatomic, strong) NSArray *',
    'NSMutableArray': '@property (nonatomic, strong) NSMutableArray *',
    'NSSet': '@property (nonatomic, strong) NSSet *',
    'NSMutableSet': '@property (nonatomic, strong) NSMutableSet *',
    'NSDictionary': '@property (nonatomic, strong) NSDictionary *',
    'NSMutableDictionary': '@property (nonatomic, strong) NSMutableDictionary *',
    'NSDate': '@property (nonatomic, strong) NSDate *',
    'NSData': '@property (nonatomic, strong) NSData *',
    'UIImage': '@property (nonatomic, strong) UIImage *',
    'UIFont': '@property (nonatomic, strong) UIFont *',
    'NSURL': '@property (nonatomic, strong) NSURL *',
    'NSNumber': '@property (nonatomic, strong) NSNumber *',
    'NSValue': '@property (nonatomic, strong) NSValue *',
    }

scheme_map_header_file_name_tpl = 'YPPRouterMap.h'
scheme_map_header_file_tpl = '''//
//  YPPRouterMap.h
//  ypp-router
//
//  Created by AutoGen.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface YPPRouterMap : NSObject

@end

NS_ASSUME_NONNULL_END

'''

scheme_map_impl_file_name_tpl = 'YPPRouterMap.m'
scheme_map_impl_file_tpl = '''//
//  YPPRouterMap.m
//  ypp-router
//
//  Created by AutoGen on.
//

#import "YPPRouterMap.h"

@implementation YPPRouterMap

+ (NSDictionary *)schemeMap {
    return @{
{scheme_map}
    };
}

@end
'''


# 字符串首字母大写，用于组装驼峰式
def normalize(s, upper=True):
    if (len(s) < 1):
        return ''
    if upper == True:
        return s[0].upper() + s[1:]
    else:
        return s[0].lower() + s[1:]

# 查找 //或/ 在path中的位置，找不到时返回0
def find_prefix_index(path):
    index = path.find('//')
    if index > 0:
        index = index + 2 
    else:
        index = path.find('/')
        if index == 0:
            index = index + 1
        else:
            index = 0
    return index

# 过滤掉scheme前缀，如xiaoxingqiu://
def filter_prefix(path):
    index = find_prefix_index(path)
    return path[index:]
    
# 将url path转换为驼峰式path_id
# 示例：xiaoxingqiu://npage/moments/topicList，结果：NpageMomentsTopicList
def transfer_path_id(path):
    index = find_prefix_index(path)
    token_list = path[index:].split('/')
    return ''.join(map(lambda s: normalize(s), token_list))
    
# 从移动之家拉取数据
def fetch_config_from_mobile(app):
    response = urllib.request.urlopen("https://mobile.yupaopao.com/scheme/export/scheme.json?appId=" + app)

    source = json.loads(response.read().decode('utf-8'))

    source = json.loads(source['data'])
    
    # with open('input/'+app+'.json', "r") as f:
    #     source = json.loads(f.read())
    return source

# 生成注释
def gen_comments(desc):
    if desc is not None and len(desc) > 0:
        return '/// %s' % desc
    else:
        return '///'

# 生成属性定义
def gen_property_definitions(params):
    if len(params) == 0:
       return gen_comments('无参数定义') 
   
    result = []
    for param in params:
        type = param['type']
        desc = param['desc']
        name = param['param']
        required = param['required']
        if required == 1:
        	result.append(gen_comments(desc + ' （参数必传）'))
        else:
        	result.append(gen_comments(desc + ' （参数可选）'))
        
        try:
            if type in params_type_map:
                property_def = params_type_map[type] + name + ';'
                result.append(property_def)
            else:
                print('参数类型不存在，默认格式')
                print(param)
                property_def = '@property (nonatomic) ' + type + ' *' + name + ';'
                result.append(property_def)
            pass
        except Exception as e:
            print("参数类型错误！！")
            raise
        
    
    return '\n'.join(result)

def build_function_name(module_name, action_name):
    if app_id == '9':
        action_name = action_name.replace('hug_', '')
    return '%s_%s' % (normalize(module_name, False), action_name)

# 生成方法定义
def gen_function_definitions(module_name, action, params_builder_name):
    result = []
    if 'desc' in action:
        result.append(gen_comments(action['desc']))
        
    if 'actionName' in action:
        result.append('- (void)%s:(void (^)(%s *builder))buildBlock;' % (build_function_name(module_name, action['actionName']), params_builder_name))
    return '\n'.join(result)

# 生成头文件 
def gen_header_file(module_name, data, save_dir, app_version):
    header_file_name = header_file_name_tpl.replace('{module_name}', module_name)
    
    content = header_file_content_tpl
    content = content.replace('{module_name}', module_name)
    
    params_definition_list = []
    function_definition_list = []
    
    result = []
    for item in data:

        # 判断版本号，是否需要导出
        if not versionCompare(item['action']['startVersion'], app_version):
            print('该scheme不需要导出' + item['path_id'])
            continue

        params_definition_list.append('#pragma mark - %s ' % item['path_id'])
        path_id = transfer_path_id(item['path_id'])
        definition = params_definition_tpl
        
        params_builder_name = params_builder_name_tpl.replace('{path_id}', path_id)
        definition = definition.replace('{params_builder_name}', params_builder_name)
        definition = definition.replace('{module_name}', module_name)
        definition = definition.replace('{property_definition}', gen_property_definitions(item['params']))
        params_definition_list.append(definition)
        
        function_definition_list.append(gen_function_definitions(module_name, item['action'], params_builder_name))
        function_definition_list.append('')
        
        result.append([item['path_id'], build_function_name(module_name, item['action']['actionName']), params_builder_name])

    action_definition = action_definition_tpl.replace('{module_name}', module_name)
    action_definition = action_definition.replace('{function_definition}', '\n'.join(function_definition_list))
    
    content = content.replace('{params_definition}', '\n'.join(params_definition_list))
    content = content.replace('{action_definition}', action_definition)
    
    output_path = os.path.join(save_dir, header_file_name)
    with open(output_path, "w") as f:
        f.write(content)
        
    return result

# 生成m文件
def gen_impl_file(module_name, params_builder_name_list, save_dir):
    impl_file_name = impl_file_name_tpl.replace('{module_name}', module_name)
    
    content = impl_file_content_tpl
    content = content.replace('{module_name}', module_name)
    
    temp = []
    result = []
    for params_builder_name in params_builder_name_list:
        temp.append(impl_method_tpl.replace('{params_builder_name}', params_builder_name))

    content = content.replace('{impl_content}', '\n'.join(temp))
    
    output_path = os.path.join(save_dir, impl_file_name)
    with open(output_path, "w") as f:
        f.write(content)

# 生成scheme映射表
def gen_scheme_map(schem_map_list, save_dir):
    scheme_map_header_file_name = scheme_map_header_file_name_tpl
    file_content = scheme_map_header_file_tpl
    
    output_path = os.path.join(save_dir, scheme_map_header_file_name)
    with open(output_path, "w") as f:
        f.write(file_content)
        
    scheme_map_impl_file_name = scheme_map_impl_file_name_tpl
    file_content = scheme_map_impl_file_tpl
        
    temp = []
    for scheme_map in schem_map_list:
        path_id = '/' + filter_prefix(scheme_map[0])
        action = scheme_map[1]
        temp.append('\t\t@"%s": @"%s:",' % (path_id, action))
    
    file_content = file_content.replace('{scheme_map}', '\n'.join(temp))  
        
    output_path = os.path.join(save_dir, scheme_map_impl_file_name)
    with open(output_path, "w") as f:
        f.write(file_content)
    return

def versionCompare(a, b):
    la = a.split('.')
    lb = b.split('.')
    f = 0
    if len(la) > len(lb):
        f = len(la)
    else:
        f = len(lb)
    for i in range(f):
        try:
            if int(la[i]) > int(lb[i]):
                print(a + ' > ' + b)
                return False
            elif int(la[i]) == int(lb[i]):
                continue
            else:
                return True
        except IndexError as e:
            if len(la) > len(lb):
                print(a + ' > ' + b)
                return False
            else:
                return True
    return True

if __name__ == '__main__':
    argv = sys.argv

    app_id = '3'
    respository_path = ''
    remote_url = 'git'
    respository_name = ''
    app_name = '3'
    app_version = '1000'
    app_language = 'OC'

    if len(argv) > 1:
        app_id = argv[1]
    print('AppId:' + app_id)
    if app_id == '1':
        remote_url = 'git@git.yupaopao.com:terminal/ios/bixin/ypp-router-bx-autogen.git'
        respository_name = 'ypp-router-bx-autogen'
        app_name = '1'
    if app_id == '2':
        remote_url = 'git@git.yupaopao.com:terminal/ios/yuer/ypp-router-yr-autogen.git'
        respository_name = 'ypp-router-yr-autogen'
        app_name = '2'
    if app_id == '3':
        remote_url = 'git@git.yupaopao.com:terminal/ios/xxq/ypp-router-xxq-autogen.git'
        respository_name = 'ypp-router-xxq-autogen'
        app_name = '3'
    if app_id == '4':
        remote_url = 'git@git.yupaopao.com:terminal/ios/xxq/ypp-router-livehelp-autogen.git'
        respository_name = 'ypp-router-livehelp-autogen'
        app_name = '4'
    if app_id == '8':
        remote_url = 'git@git.yupaopao.com:terminal/ios/tangdou/ypp-router-tg-autogen.git'
        respository_name = 'ypp-router-tg-autogen'
        app_name = '8'
    if app_id == '9':
        remote_url = 'git@git.yupaopao.com:hugging/client/ios/ypp-router-hug-autogen.git'
        respository_name = 'ypp-router-hug-autogen'
        app_name = '9'
    if app_id == '10':
        remote_url = 'git@git.yupaopao.com:terminal/ios/community/ypp-router-pt-autogen.git'
        respository_name = 'ypp-router-pt-autogen'
        app_name = '10'
    if app_id == '12':
        remote_url = 'git@git.yupaopao.com:terminal/ios/singtogether/ypp-router-st-autogen.git'
        respository_name = 'ypp-router-st-autogen'
        app_name = '12'
    if app_id == '13':
        remote_url = 'git@git.yupaopao.com:terminal/ios/zaixin/ypp-router-mvp-autogen.git'
        respository_name = 'ypp-router-mvp-autogen'
        app_name = '13'
    if app_id == '14':
        remote_url = 'git@git.yupaopao.com:terminal/ios/matrixapps/MatrixApp/ypp-router-mt-autogen.git'
        respository_name = 'ypp-router-mt-autogen'
        app_name = '14'
    if app_id == '15':
        remote_url = 'git@git.yupaopao.com:chuke/terminal/ios/ckypp-router-yr-autogen.git'
        respository_name = 'ckypp-router-yr-autogen'
        app_name = '15'
    if app_id == '16':
        remote_url = 'git@git.yupaopao.com:terminal/ios/fantang/ypp-router-ft-autogen.git'
        respository_name = 'ypp-router-ft-autogen'
        app_name = '16'

    if len(argv) > 2:
        if argv[2] == 'OC' or argv[2] == 'swift':
            app_language = argv[2]
            print('language:' + app_language)
        else:
            app_version = argv[2]
    print('app_version:' + app_version)

    if len(argv) > 3:
        app_language = argv[3]
        print('language:' + app_language)

    print('respository_name:' + respository_name)

    respository_path = os.getcwd()

    os.chdir(respository_path)
    print('当前路径' + os.getcwd())

    filePath = respository_path + '/' + respository_name

    if os.path.exists(filePath):
        print('git仓库存在')
    else:
        os.system('git clone %s' % remote_url)
        print('新建git仓库')

    os.chdir(respository_name)
    print('当前路径0' + os.getcwd())

    os.system('git pull --rebase origin master')

    os.chdir('Pods/Classes')
    print('当前路径1' + os.getcwd())
    os.system('rm -rf *')

    source = fetch_config_from_mobile(app_name)

    save_dir = '%s/%s/Pods/Classes' % (respository_path, respository_name)
    
    if not os.path.exists(save_dir):
        os.makedirs(save_dir);
    
    schem_map_list = []
    if app_language == 'OC':
        for module in source:
            try:
                module_name = normalize(module)
                list = gen_header_file(module_name, source[module], save_dir, app_version)
                params_builder_name_list = map(lambda x: x[2], list)
                gen_impl_file(module_name, params_builder_name_list, save_dir)
        
                print('[Done] moudle: %s' % module_name)
        
                schem_map_list = schem_map_list + list
                pass
            except Exception as e:
                print('导出失败的文件！！')
                print (module)
                raise
        
            gen_scheme_map(schem_map_list, save_dir)
            print('[Done] scheme map')
    elif app_language == 'swift':
        for module in source:
            try:
                module_name = normalize(module)
                list = swiftAutogen.gen_header_file(module_name, source[module], save_dir, app_version)
                print('[Done] moudle: %s' % module_name)
        
                schem_map_list = schem_map_list + list
                print('swift [Done] module: %s' % module_name)
            except Exception as e:
        	    print('swift 导出失败的文件！！ %s' % module)
        	    raise
            swiftAutogen.gen_scheme_map(schem_map_list, save_dir)
            print('[Done] scheme map')

    

    os.chdir(respository_path + '/' + respository_name)

    print('当前路径2' + os.getcwd())

    os.system('git status')
    os.system('git add -A')
    os.system('git commit -a -m \'更新版本\'')
    os.system('git status')
    os.system('git push -u origin master')
    os.system('git push -f')
    print('推送到远端')

