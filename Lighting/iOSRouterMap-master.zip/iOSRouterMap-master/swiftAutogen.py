import os

header_file_name_tpl = 'YPPRouter+{module_name}.swift'

params_builder_name_tpl = 'YPP{path_id}ParamsBuilder'

header_file_content_tpl = '''//
//  YPPRouter+{module_name}.swift
//  ypp-router
//
//  Created by AutoGen.
//

import Foundation
import Lighting

{params_definition}
{action_definition}
{impl_definition}
{router_definition}
'''

params_definition_tpl = '''
@objcMembers
open class {params_builder_name} : YPPBaseParamsBuilder {
{property_definition}
}
'''

action_definition_tpl = '''
//MARK: - action definition
@objc
public protocol YPPRouter{module_name}Delegate {

{function_definition}
}
'''

impl_file_content_tpl = '''extension YPPRouter: YPPRouter{module_name}Delegate {
    
}
'''

router_definition_tpl = '''
//MARK: - router class function definition

extension Router {
{class_function_definition}
}
'''

class_function_definition_tpl = '''
	open class func {function_definition}(_ buidler: @escaping ({params_builder_name}) -> Void) {
        
        let block: ({params_builder_name}) -> Void = buidler
        let compatibilityBlock = block as @convention(block) ({params_builder_name}) -> Void
        let compatibilityBlockObject = unsafeBitCast(compatibilityBlock, to: AnyObject.self)

        YPPRouterURLParser.sharedInstance().safePerformAction(#selector(YPPRouter{module_name}Delegate.{function_definition}(_:)), target: YPPRouter.shared(), params: compatibilityBlockObject)
    }
'''

scheme_map_header_file_name_tpl = 'YPPRouterMap.swift'
scheme_map_header_file_tpl = '''//
//  YPPRouterMap.swift
//  ypp-router
//
//  Created by AutoGen.
//

import Foundation
import Lighting

/// swift 路由入口
open class Router: YPPRouter {}

@objc(YPPRouterMap)
class YPPRouterMap: NSObject {
    
    @objc
    static func schemeMap() -> NSDictionary {
        return [
{scheme_map}
        ]
    }
}
'''

property_definition_detail_tpl = '''
{property_detail_tpl}

{replaced_property_tpl}
{override_replacedKey_tpl}'''

replaced_property_tpl = '''    public var _{param_name}: NSNumber?'''

function_override_replacedKey_tpl = '''
    open override func ym_replacedKeyFromPropertyName() -> [String : String] {
        return [
            {params_replaced_map}
        ]
    }
'''

params_replaced_map_definition = '''"{param_name}" : "_{param_name}",
            '''

params_type_map = {

    'string': 'var {param_name}: String = ""',
    'int': 'var {param_name}: Int {set { _{param_name} = NSNumber(value: newValue) } get{ _{param_name}?.intValue ?? 0 }}',
    'bool': 'var {param_name}: Bool {set { _{param_name} = NSNumber(value: newValue) } get{ _{param_name}?.boolValue ?? false }}',
    'BOOL': 'var {param_name}: Bool {set { _{param_name} = NSNumber(value: newValue) } get{ _{param_name}?.boolValue ?? false }}',
    'integer': 'var {param_name}: Int {set { _{param_name} = NSNumber(value: newValue) } get{ _{param_name}?.intValue ?? 0 }}',
    'float': 'var {param_name}: Float {set { _{param_name} = NSNumber(value: newValue) } get{ _{param_name}?.floatValue ?? 0 }}',
    'double': 'var {param_name}: Double {set { _{param_name} = NSNumber(value: newValue) } get{ _{param_name}?.doubleValue ?? 0 }}',

    'CGRect': 'var {param_name}: CGRect = .zero',
    'CGSize': 'var {param_name}: CGSize = .zero',
    'CGFloat': 'var {param_name}: CGFloat = .zero',
    'CGPoint': 'var {param_name}: CGPoint = .zero',
    'UIEdgeInsets': 'var {param_name}: UIEdgeInsets = .zero',

    'Class': 'var {param_name}: AnyClass = AnyObject.self',
    'id': 'var {param_name}: Any?',
    'iOS_id': 'var {param_name}: Any?',
    'NSRange': 'var {param_name}: NSRange?',
    'NSArray': 'var {param_name}: [Any] = []',
    'NSMutableArray': 'var {param_name}: [Any] = []',
    'NSSet': 'var {param_name}: Set[Any] = []',
    'NSMutableSet': 'var {param_name}: Set[Any] = []',
    'NSDictionary': 'var {param_name}: [String: Any] = [:]',
    'NSMutableDictionary': 'var {param_name}: [String: Any] = [:]',
    'NSDate': 'var {param_name}: Date?',
    'NSData': 'var {param_name}: Data?',
    'UIImage': 'var {param_name}: UIImage?',
    'UIFont': 'var {param_name}: UIFont?',
    'NSURL': 'var {param_name}: URL?',
    'NSNumber': 'var {param_name}: NSNumber?',
    'NSValue': 'var {param_name}: NSValue?',
    }

params_type_optional_map = {
    'string': 'var {param_name}: String?',
    'int': 'var {param_name}: Int {set { _{param_name} = NSNumber(value: newValue) } get{ _{param_name}?.intValue ?? 0 }}',
    'bool': 'var {param_name}: Bool {set { _{param_name} = NSNumber(value: newValue) } get{ _{param_name}?.boolValue ?? false }}',
    'BOOL': 'var {param_name}: Bool {set { _{param_name} = NSNumber(value: newValue) } get{ _{param_name}?.boolValue ?? false }}',
    'integer': 'var {param_name}: Int {set { _{param_name} = NSNumber(value: newValue) } get{ _{param_name}?.intValue ?? 0 }}',
    'float': 'var {param_name}: Float {set { _{param_name} = NSNumber(value: newValue) } get{ _{param_name}?.floatValue ?? 0 }}',
    'double': 'var {param_name}: Double {set { _{param_name} = NSNumber(value: newValue) } get{ _{param_name}?.doubleValue ?? 0 }}',

    'CGRect': 'var {param_name}: CGRect?',
    'CGSize': 'var {param_name}: CGSize?',
    'CGFloat': 'var {param_name}: CGFloat?',
    'CGPoint': 'var {param_name}: CGPoint?',
    'UIEdgeInsets': 'var {param_name}: UIEdgeInsets?',

    'Class': 'var {param_name}: AnyClass?',
    'id': 'var {param_name}: Any?',
    
    'NSRange': 'var {param_name}: NSRange?',
    'NSArray': 'var {param_name}: [Any]?',
    'NSMutableArray': 'var {param_name}: [Any]?',
    'NSSet': 'var {param_name}: Set[Any]?',
    'NSMutableSet': 'var {param_name}: Set[Any]?',
    'NSDictionary': 'var {param_name}: [String: Any]?',
    'NSMutableDictionary': 'var {param_name}: [String: Any]?',
    'NSDate': 'var {param_name}: Date?',
    'NSData': 'var {param_name}: Data?',
    'UIImage': 'var {param_name}: UIImage?',
    'UIFont': 'var {param_name}: UIFont?',
    'NSURL': 'var {param_name}: URL?',
    'NSNumber': 'var {param_name}: NSNumber?',
    'NSValue': 'var {param_name}: NSValue?',
    }


# 生成头文件 
def gen_header_file(module_name, data, save_dir, app_version):
    header_file_name = header_file_name_tpl.replace('{module_name}', module_name)
    
    content = header_file_content_tpl
    content = content.replace('{module_name}', module_name)
    
    params_definition_list = []
    function_definition_list = []
    class_function_definition_list = []
    
    result = []
    for item in data:

        # 判断版本号，是否需要导出
        if not versionCompare(item['action']['startVersion'], app_version):
            print('该scheme不需要导出' + item['path_id'])
            continue

        params_definition_list.append('//MARK: - %s ' % item['path_id'])
        path_id = transfer_path_id(item['path_id'])
        definition = params_definition_tpl
        
        params_builder_name = params_builder_name_tpl.replace('{path_id}', path_id)
        definition = definition.replace('{params_builder_name}', params_builder_name)
        definition = definition.replace('{module_name}', module_name)
        definition = definition.replace('{property_definition}', gen_property_definitions(item['params']))
        params_definition_list.append(definition)
        
        function_definition_list.append(gen_function_definitions(module_name, item['action'], params_builder_name))
        function_definition_list.append('')

        class_function_definition_list.append(gen_class_function_definitions(build_function_name(module_name, item['action']['actionName']), module_name, params_builder_name))
        
        result.append([item['path_id'], build_function_name(module_name, item['action']['actionName']), params_builder_name])

    action_definition = action_definition_tpl.replace('{module_name}', module_name)
    action_definition = action_definition.replace('{function_definition}', '\n'.join(function_definition_list))

    router_definition = router_definition_tpl.replace('{class_function_definition}', ''.join(class_function_definition_list))
    
    content = content.replace('{params_definition}', '\n'.join(params_definition_list))
    content = content.replace('{action_definition}', action_definition)
    content = content.replace('{impl_definition}', gen_imp_definitions(module_name))
    content = content.replace('{router_definition}', router_definition)
    
    output_path = os.path.join(save_dir, header_file_name)
    with open(output_path, "w") as f:
        f.write(content)
        
    return result

# 生成属性定义
def gen_property_definitions(params):
    if len(params) == 0:
       return gen_comments('无参数定义') 
   
    replacedDic = []
    replacedProperty = []
    result = []
    for param in params:
        type = param['type']
        desc = param['desc']
        name = param['param']
        required = param['required']
        if required == 1:
        	result.append('\t' + gen_comments(desc + ' （参数必传）'))
        else:
        	result.append('\t' + gen_comments(desc + ' （参数可选）'))
        
        try:
            if type in params_type_map:
                property_def = ''
                if type == 'int' or type == 'integer' or type == 'BOOL' or type == 'bool':
                    replacedProperty.append(replaced_property_tpl.replace('{param_name}', name))
                    replacedDic.append(params_replaced_map_definition.replace('{param_name}', name))
                if required == 1:
            	    property_def = params_type_map[type].replace('{param_name}', name)
                else:
                    property_def = params_type_optional_map[type].replace('{param_name}', name)
                result.append('\tpublic ' + property_def)
            else:
                print('参数类型不存在，默认格式')
                print(param)
                property_def = 'var' + name + ': ' + type + '?'
                result.append('\tpublic ' + property_def)
            pass
        except Exception as e:
            print("参数类型错误！！")
            raise
        
    content = property_definition_detail_tpl.replace('{property_detail_tpl}', '\n'.join(result))
    content = content.replace('{replaced_property_tpl}', '\n'.join(replacedProperty))
    if len(replacedDic) > 0:
        overrideMap = function_override_replacedKey_tpl.replace('{params_replaced_map}', ''.join(replacedDic))
        content = content.replace('{override_replacedKey_tpl}', overrideMap)
    else:
        content = content.replace('{override_replacedKey_tpl}', "")
    return content


# 生成注释
def gen_comments(desc):
    if desc is not None and len(desc) > 0:
        return '/// %s' % desc
    else:
        return '///'

# 生成方法定义
def gen_function_definitions(module_name, action, params_builder_name):
    result = []
    if 'desc' in action:
        result.append('\t' + gen_comments(action['desc']))
        
    if 'actionName' in action:
        result.append('@objc optional\n\tfunc %s(_ buidler: (%s) -> Void)' % (build_function_name(module_name, action['actionName']), params_builder_name))
    return '\n\t'.join(result)

def build_function_name(module_name, action_name):
    return '%s_%s' % (normalize(module_name, False), action_name)

def gen_imp_definitions(module_name):
    result = impl_file_content_tpl.replace('{module_name}', module_name)
    return result

def gen_class_function_definitions(function_name, module_name, params_builder_name):

	class_function_definition = class_function_definition_tpl.replace('{function_definition}', function_name)
	class_function_definition = class_function_definition.replace('{params_builder_name}', params_builder_name)
	class_function_definition = class_function_definition.replace('{module_name}', module_name)
	return class_function_definition

# 生成scheme映射表
def gen_scheme_map(schem_map_list, save_dir):
    
    scheme_map_impl_file_name = scheme_map_header_file_name_tpl
    file_content = scheme_map_header_file_tpl
        
    temp = []
    for scheme_map in schem_map_list:
        path_id = '/' + filter_prefix(scheme_map[0])
        action = scheme_map[1]
        temp.append('\t\t"%s": "%s:",' % (path_id, action))
    
    file_content = file_content.replace('{scheme_map}', '\n'.join(temp))  
        
    output_path = os.path.join(save_dir, scheme_map_impl_file_name)
    with open(output_path, "w") as f:
        f.write(file_content)
    return


# 字符串首字母大写，用于组装驼峰式
def normalize(s, upper=True):
    if (len(s) < 1):
        return ''
    if upper == True:
        return s[0].upper() + s[1:]
    else:
        return s[0].lower() + s[1:]

# 查找 //或/ 在path中的位置，找不到时返回0
def find_prefix_index(path):
    index = path.find('//')
    if index > 0:
        index = index + 2 
    else:
        index = path.find('/')
        if index == 0:
            index = index + 1
        else:
            index = 0
    return index

# 过滤掉scheme前缀，如xiaoxingqiu://
def filter_prefix(path):
    index = find_prefix_index(path)
    return path[index:]
    
# 将url path转换为驼峰式path_id
# 示例：xiaoxingqiu://npage/moments/topicList，结果：NpageMomentsTopicList
def transfer_path_id(path):
    index = find_prefix_index(path)
    token_list = path[index:].split('/')
    return ''.join(map(lambda s: normalize(s), token_list))
    
def versionCompare(a, b):
    la = a.split('.')
    lb = b.split('.')
    f = 0
    if len(la) > len(lb):
        f = len(la)
    else:
        f = len(lb)
    for i in range(f):
        try:
            if int(la[i]) > int(lb[i]):
                print(a + ' > ' + b)
                return False
            elif int(la[i]) == int(lb[i]):
                continue
            else:
                return True
        except IndexError as e:
            if len(la) > len(lb):
                print(a + ' > ' + b)
                return False
            else:
                return True
    return True





